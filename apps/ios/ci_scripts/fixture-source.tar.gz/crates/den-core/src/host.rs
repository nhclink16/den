use crate::Id;
use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

/// UTF-8 JSON inside binary WebSocket messages. Byte fields contain octets.
/// Open is idempotent: an existing PTY sends its recent scrollback and resizes.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum HostFrame {
    Open {
        session_id: Id,
        cols: u16,
        rows: u16,
        shell: Option<String>,
    },
    Input {
        session_id: Id,
        bytes: Vec<u8>,
    },
    Resize {
        session_id: Id,
        cols: u16,
        rows: u16,
    },
    Close {
        session_id: Id,
    },
    Output {
        session_id: Id,
        bytes: Vec<u8>,
    },
    Exited {
        session_id: Id,
        code: u32,
    },
    Ack {
        session_id: Id,
        bytes: usize,
    },
    Viewer {
        session_id: Id,
        user_id: Id,
        name: String,
    },
    Hello {
        direct_url: Option<String>,
        /// Retained PTYs. None identifies a legacy host, not an empty inventory.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        session_ids: Option<Vec<Id>>,
    },
    Replay {
        session_id: Id,
        connection_id: Id,
    },
    Scrollback {
        session_id: Id,
        connection_id: Id,
        bytes: Vec<u8>,
    },
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct HostLogin {
    pub code: String,
    pub name: String,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct HostCredential {
    pub server_url: String,
    pub host_id: Id,
    pub name: String,
    pub token: String,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct DirectCheck {
    pub token: String,
    pub session_id: Id,
    pub input: bool,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct DirectPermission {
    pub user_id: Id,
    pub name: String,
    pub owner: bool,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum TerminalFrame {
    TerminalInput {
        session_id: Id,
        bytes: Vec<u8>,
    },
    TerminalResize {
        session_id: Id,
        cols: u16,
        rows: u16,
    },
    TerminalOpen {
        session_id: Id,
    },
    TerminalClose {
        session_id: Id,
    },
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct Host {
    pub id: Id,
    pub owner_id: Id,
    pub name: String,
    pub online: bool,
    pub last_seen: Option<i64>,
    pub direct_url: Option<String>,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct HostEnrollment {
    pub code: String,
    pub expires_at: i64,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, ToSchema)]
#[serde(rename_all = "snake_case")]
pub enum Capability {
    TerminalView,
    TerminalControl,
}
impl Capability {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::TerminalView => "terminal_view",
            Self::TerminalControl => "terminal_control",
        }
    }
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct Grant {
    pub id: Id,
    pub host_id: Id,
    pub grantee_id: Id,
    pub capability: Capability,
    pub expires_at: Option<i64>,
    pub created_by: Id,
    pub created_at: i64,
    pub revoked_at: Option<i64>,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct RequestAccess {
    pub capability: Capability,
    pub duration_minutes: Option<u32>,
    #[serde(default)]
    pub standing: bool,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct AccessRequest {
    pub id: Id,
    pub host_id: Id,
    pub host_name: String,
    pub owner_id: Id,
    pub requester_id: Id,
    pub capability: Capability,
    pub duration_minutes: Option<u32>,
    pub standing: bool,
    pub status: String,
    pub expires_at: i64,
    #[schema(value_type = Option<String>)]
    pub grant_id: Option<Id>,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct AccessDecision {
    pub allow: bool,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct AccessLog {
    pub id: Id,
    pub host_id: Id,
    pub actor_id: Id,
    pub action: String,
    #[schema(value_type = Option<String>)]
    pub subject_id: Option<Id>,
    pub created_at: i64,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct OpenTerminal {
    #[schema(value_type = Option<String>)]
    pub channel_id: Option<Id>,
    pub cols: Option<u16>,
    pub rows: Option<u16>,
    /// Conversation context, so a task's first card can land with the work that
    /// caused it. The object still belongs to its message; this is not a second
    /// thread assignment.
    #[serde(default)]
    #[schema(value_type = Option<String>)]
    pub thread_id: Option<Id>,
    #[serde(default)]
    pub task_id: Option<String>,
    #[serde(default)]
    #[schema(value_type = Option<String>)]
    pub reply_to: Option<Id>,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct TerminalState {
    pub id: Id,
    pub host_id: Id,
    pub host_name: String,
    pub owner_id: Id,
    pub cols: u16,
    pub rows: u16,
    #[schema(value_type = Option<String>)]
    pub active_controller_id: Option<Id>,
    pub viewer_ids: Vec<Id>,
    pub ended_at: Option<i64>,
    pub started_at: i64,
    #[schema(value_type = Option<String>)]
    pub recording_upload_id: Option<Id>,
    #[serde(default)]
    pub recording_enabled: bool,
    pub recording_capped: bool,
    pub control_request_ids: Vec<Id>,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct SetController {
    #[schema(value_type = Option<String>)]
    pub user_id: Option<Id>,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct ShareTerminal {
    pub channel_id: Id,
    #[serde(default)]
    #[schema(value_type = Option<String>)]
    pub thread_id: Option<Id>,
    #[serde(default)]
    pub task_id: Option<String>,
    #[serde(default)]
    #[schema(value_type = Option<String>)]
    pub reply_to: Option<Id>,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct TerminalWrite {
    pub text: String,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct DirectToken {
    pub token: String,
    pub url: Option<String>,
    pub expires_at: i64,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, ToSchema)]
pub struct TerminalRecording {
    pub enabled: bool,
}
