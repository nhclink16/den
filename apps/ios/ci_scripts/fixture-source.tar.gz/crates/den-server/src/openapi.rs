use crate::*;
use den_core::Object as LiveObject;
use utoipa::OpenApi;
#[derive(OpenApi)]
#[openapi(
    info(
        title = "Den API",
        version = "0.1.0",
        description = "M3 REST API. Cookie-authenticated writes require Origin and X-CSRF-Token. CLI and agents use bearer authentication. Entity IDs are ULIDs; background image IDs are opaque SHA-256 content IDs."
    ),
    paths(
        music::get,
        music::add,
        music::remove,
        music::skip,
        music::pause,
        music::seek,
        music::order,
        sounds::get_server,
        sounds::get,
        sounds::put,
        sounds::put_file,
        sounds::get_file,
        sounds::put_server,
        sounds::server_file,
        sounds::import_pack,
        sounds::export_pack,
        sounds::preview,
        sounds::preview_file,
        sounds::install_attachment,
        health,
        profiles::patch,
        profile_images::put_avatar,
        profile_images::put_banner,
        profile_images::put_bot_avatar,
        profile_images::get_avatar,
        profile_images::get_banner,
        profile_images::delete_avatar,
        profile_images::delete_banner,
        objects::instance,
        tickets::issue,
        voice_preferences::get,
        voice_preferences::put,
        appearance::get_appearance,
        appearance::put_appearance,
        backgrounds::put,
        backgrounds::get,
        backgrounds::remove,
        hosts::list,
        hosts::enroll,
        hosts::login,
        hosts::remove,
        hosts::connect,
        hosts::direct_check,
        access::request,
        access::decide,
        access::grants,
        access::revoke,
        access::log,
        terminal_recording::get,
        terminal_recording::put,
        terminal_recording::set,
        terminal::open,
        terminal::controller,
        terminal::request_control,
        terminal::share,
        terminal::write,
        terminal::close,
        terminal::direct_token,
        objects::settings,
        objects::save_settings,
        objects::create,
        objects::get,
        objects::summary,
        objects::patch,
        objects::update,
        auth::bootstrap,
        auth::register,
        auth::login,
        auth::logout,
        devices::register,
        devices::remove,
        auth::me,
        auth::users,
        credentials::invite,
        credentials::revoke_invite,
        credentials::tokens,
        credentials::create_token,
        credentials::revoke_token,
        credentials::bot,
        chat::categories,
        chat::create_category,
        chat::update_category,
        chat::delete_category,
        chat::channels,
        chat::channel,
        chat::create_channel,
        chat::update_channel,
        chat::delete_channel,
        chat::dm,
        messages::messages,
        messages::send,
        messages::edit,
        messages::remove,
        uploads::begin,
        uploads::status,
        uploads::remove,
        uploads::chunk,
        uploads::complete,
        uploads::file,
        activity::message,
        activity::react,
        activity::unreact,
        activity::search,
        inbox::get_preferences,
        inbox::put_preferences,
        inbox::read_states,
        inbox::mark_read,
        ws::presence,
        calls::token,
        calls::list,
        invitations::invite,
        invitations::decline,
        invitations::accept,
        invitations::cancel,
        invitations::end,
        invitations::list,
        invitations::get,
        invitation_tickets::redeem,
        calls::webhook,
        thumbnails::serve,
        ws::connect
    ),
    components(schemas(
        ProfilePatch,
        Status,
        SoundEvent,
        SoundRef,
        SoundPack,
        SoundPreferences,
        ResolvedSound,
        SoundState,
        InstallSound,
        VoicePreferences,
        MicrophoneSettings,
        CameraSettings,
        CameraResolution,
        Appearance,
        Background,
        BackgroundSource,
        BackgroundBuiltin,
        BackgroundScope,
        BackgroundFit,
        BackgroundImage,
        Theme,
        ThemeColors,
        ThemeFonts,
        ThemeAppearance,
        AppearanceMode,
        ThemeRadius,
        ThemeDensity,
        Host,
        HostEnrollment,
        HostCredential,
        HostLogin,
        HostFrame,
        TerminalFrame,
        Capability,
        Grant,
        RequestAccess,
        AccessRequest,
        AccessDecision,
        AccessLog,
        OpenTerminal,
        TerminalState,
        TerminalRecording,
        SetController,
        ShareTerminal,
        TerminalWrite,
        DirectToken,
        DirectCheck,
        DirectPermission,
        Event,
        LiveObject,
        ObjectSummary,
        CreateObject,
        ObjectPatch,
        UpdateObject,
        ObjectVersion,
        ObjectPresence,
        Settings,
        UpdateSettings,
        ApiError,
        Health,
        Instance,
        WsTicket,
        User,
        Role,
        Channel,
        ChannelKind,
        Message,
        Upload,
        Session,
        Login,
        Register,
        Bootstrap,
        CreateInvite,
        Invite,
        CreateToken,
        Token,
        TokenSecret,
        CreateBot,
        BotCreated,
        Category,
        SaveCategory,
        SaveChannel,
        CreateDm,
        CreateMessage,
        EditMessage,
        MessageQuery,
        BeginUpload,
        Reaction,
        SetReaction,
        MarkRead,
        ChannelReadState,
        NotificationPreferences,
        NotificationReason,
        SearchMessages,
        ClientEvent,
        PresenceState,
        CallToken,
        CallState,
        MusicQueue,
        MusicTrack,
        MusicTrackState,
        AddMusic,
        PauseMusic,
        SeekMusic,
        OrderMusic,
        DevicePlatform,
        DevicePurpose,
        DeviceEnvironment,
        RegisterDevice,
        Device,
        CallInvitation,
        DeclineCallInvitation,
        InvitationStatus,
        CallAcceptance,
        CallInvitationState,
        AcceptCallInvitation,
        IdentifyCallInvitation,
        RedeemCallInvitation,
        IncomingVoipCall
    ))
)]
struct Api;
pub(crate) async fn serve() -> Json<utoipa::openapi::OpenApi> {
    use utoipa::openapi::{
        security::{
            ApiKey, ApiKeyValue, Http, HttpAuthScheme, SecurityRequirement, SecurityScheme,
        },
        Content, Ref, ResponseBuilder,
    };
    let mut api = Api::openapi();
    let components = api.components.as_mut().unwrap();
    components.add_security_scheme(
        "bearerAuth",
        SecurityScheme::Http(Http::new(HttpAuthScheme::Bearer)),
    );
    components.add_security_scheme(
        "sessionCookie",
        SecurityScheme::ApiKey(ApiKey::Cookie(ApiKeyValue::new("den_session"))),
    );
    api.security = Some(vec![
        SecurityRequirement::new("bearerAuth", Vec::<String>::new()),
        SecurityRequirement::new("sessionCookie", Vec::<String>::new()),
    ]);
    for (path, item) in &mut api.paths.paths {
        let public = matches!(
            path.as_str(),
            "/hosts/login"
                | "/livekit/webhook"
                | "/health"
                | "/instance"
                | "/auth/init"
                | "/auth/login"
                | "/auth/register"
                | "/calls/invitations/redeem"
        );
        for (method, op) in [
            ("get", &mut item.get),
            ("post", &mut item.post),
            ("put", &mut item.put),
            ("patch", &mut item.patch),
            ("delete", &mut item.delete),
        ]
        .into_iter()
        .filter_map(|(method, op)| op.as_mut().map(|op| (method, op)))
        {
            op.operation_id = Some(format!(
                "{method}_{}",
                path.replace(['/', '{', '}', '-'], "_")
            ));
            if public {
                op.security = Some(Vec::new());
            }
            op.responses.responses.insert("default".into(), ResponseBuilder::new().description("API error; invalid input, authentication, permissions, conflict, throttling or storage failure").content("application/json",Content::new(Some(Ref::from_schema_name("ApiError")))).build().into());
        }
        if path == "/uploads/{id}/file" || path == "/uploads/{id}/thumbnail" {
            item.head = item.get.clone();
            if let Some(op) = &mut item.head {
                op.operation_id = Some(
                    if path.ends_with("thumbnail") {
                        "thumbnail_head"
                    } else {
                        "file_head"
                    }
                    .into(),
                );
            }
        }
    }
    Json(api)
}
